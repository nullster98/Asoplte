using System.Collections.Generic;
using UnityEngine;

namespace Item
{
    [CreateAssetMenu(fileName = "ItemDatabase", menuName = "Game/Item Database")]
    public class ItemDatabase : ScriptableObject
    {
        public List<ItemData> itemList = new List<ItemData>();

        public ItemData GetItemByID(int itemID)
        {
            return itemList.Find(item => item.ItemID == itemID);
        }

        public void ResetDatabase()
        {
            itemList.Clear();
        }
    }
}



