using System.Collections;
using System.Collections.Generic;
using PlayerScript;
using UnityEngine;

public interface IEffect
{
    void ApplyEffect(IUnit target);
}
