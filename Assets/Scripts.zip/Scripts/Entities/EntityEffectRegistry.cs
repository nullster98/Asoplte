using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class EntityEffectRegistry 
{
    public static void RegisterAll()
    {
        
    }
}

internal class BossEffect : IEffect // 전용 특수 기믹 추가
{
    public string EffectDescription => null;

    public void ApplyEffect(IUnit target)
    {
        
    }
}